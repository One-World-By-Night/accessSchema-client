<?php

/** File: includes/languages/init.php
 * Text Domain: accessschema-client
 * @version 1.1.0
 * @author greghacke
 * Function: Init languages functionality for the plugin
 */

defined( 'ABSPATH' ) || exit;

/** --- Require each language file once --- */
// require_once __DIR__ . '/_template.php';
